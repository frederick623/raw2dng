#!/bin/sh
external/ndk_linux_amd64/toolchains/llvm/prebuilt/linux-x86_64/bin/clang $@
