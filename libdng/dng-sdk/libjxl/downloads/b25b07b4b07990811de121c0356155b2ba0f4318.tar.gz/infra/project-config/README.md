This directory contains project-wide configuration files for infra services.
